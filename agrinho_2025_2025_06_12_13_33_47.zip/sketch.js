let personagem;
let itensCampo = [];
let itensCidade = [];
let areaFesta;

let pontuacao = 0;
let itensNecessarios = 10; // Quantos itens para uma "fase" da festa
let nivelFesta = 0; // Começa no nível 0

let cenaAtual = 'campo'; // 'campo', 'cidade', ou 'festa'
let tempoMudancaCena = 0;
let intervaloMudancaCena = 7000; // Mudar de cena a cada 7 segundos

let imgPersonagem; // Para carregar uma imagem futura
let imgFlor; // Exemplo de item do campo
let imgViolao; // Exemplo de item da cidade

function preload() {
  // Opcional: Carregue imagens aqui se você tiver arquivos
  // imgPersonagem = loadImage('assets/personagem.png');
  // imgFlor = loadImage('assets/flor.png');
  // imgViolao = loadImage('assets/violao.png');
}

function setup() {
  createCanvas(800, 500);
  personagem = new Personagem();
  areaFesta = new AreaFesta();

  // Cria alguns itens iniciais
  for (let i = 0; i < 5; i++) {
    criarItem('campo');
    criarItem('cidade');
  }

  tempoMudancaCena = millis(); // Inicia o contador de tempo
}

function draw() {
  // Desenha o fundo baseado na cena atual
  desenharCenario();

  // Atualiza e desenha itens coletáveis
  for (let i = itensCampo.length - 1; i >= 0; i--) {
    itensCampo[i].show();
    if (personagem.coletou(itensCampo[i])) {
      pontuacao++;
      itensCampo.splice(i, 1);
      criarItem('campo'); // Gera um novo item
    }
  }

  for (let i = itensCidade.length - 1; i >= 0; i--) {
    itensCidade[i].show();
    if (personagem.coletou(itensCidade[i])) {
      pontuacao++;
      itensCidade.splice(i, 1);
      criarItem('cidade'); // Gera um novo item
    }
  }

  // Atualiza e desenha personagem
  personagem.show();
  personagem.move();

  // Desenha a área da festa (sempre visível em algum lugar)
  areaFesta.show();

  // Checa se atingiu a meta de itens para o próximo nível da festa
  if (pontuacao >= itensNecessarios) {
    nivelFesta++;
    pontuacao = 0; // Reseta a pontuação para o próximo nível
    itensNecessarios += 5; // Aumenta a dificuldade para o próximo nível
    // Manda uma mensagem de celebração
    console.log("A festa está crescendo! Nível: " + nivelFesta);
  }

  // Exibe pontuação e nível da festa
  fill(0);
  textSize(20);
  text('Itens Coletados: ' + pontuacao + '/' + itensNecessarios, 10, 30);
  text('Nível da Festa: ' + nivelFesta, 10, 60);

  // Lógica de mudança de cena
  if (millis() - tempoMudancaCena > intervaloMudancaCena) {
    mudarCena();
    tempoMudancaCena = millis();
  }
}

function desenharCenario() {
  if (cenaAtual === 'campo') {
    background(135, 206, 235); // Céu azul claro
    fill(124, 252, 0); // Verde grama
    rect(0, height * 0.7, width, height * 0.3); // Chão
    // Algumas árvores básicas para o campo
    fill(139, 69, 19); // Tronco
    rect(width * 0.2, height * 0.5, 20, 80);
    fill(34, 139, 34); // Folhas
    ellipse(width * 0.2 + 10, height * 0.5, 60, 60);

    rect(width * 0.7, height * 0.6, 20, 80);
    ellipse(width * 0.7 + 10, height * 0.6, 60, 60);

  } else if (cenaAtual === 'cidade') {
    background(173, 216, 230); // Céu azul acinzentado
    fill(105, 105, 105); // Cinza asfalto
    rect(0, height * 0.7, width, height * 0.3); // Rua
    // Alguns prédios básicos para a cidade
    fill(150); // Prédio cinza
    rect(width * 0.1, height * 0.3, 80, height * 0.4);
    fill(200); // Prédio cinza mais claro
    rect(width * 0.4, height * 0.2, 100, height * 0.5);
    fill(120); // Prédio cinza escuro
    rect(width * 0.8, height * 0.4, 70, height * 0.3);

  } else if (cenaAtual === 'festa') {
    background(255, 223, 0); // Fundo amarelo vibrante para a festa
    fill(255, 165, 0); // Laranja para o chão festivo
    rect(0, height * 0.8, width, height * 0.2);
    // Elementos visuais da festa baseados no nível
    for (let i = 0; i < nivelFesta * 5; i++) {
      fill(random(255), random(255), random(255), 150); // Confetes coloridos
      ellipse(random(width), random(height * 0.8), 10, 10);
    }
    // Adicionar luzes e notas musicais conforme o nível
    if (nivelFesta > 0) {
      fill(255, 255, 0); // Luzes amarelas
      for (let i = 0; i < nivelFesta * 2; i++) {
        ellipse(width * 0.2 + i * 50, height * 0.1, 15, 15);
      }
    }
    if (nivelFesta > 1) {
      fill(255, 0, 255); // Notas musicais
      text('♩', width * 0.3, height * 0.3);
      text('♪', width * 0.5, height * 0.2);
    }
    textSize(32);
    fill(255);
    text('A FESTA ESTÁ ACONTECENDO!', width / 2, height / 2);
  }
}

function mudarCena() {
  let cenas = ['campo', 'cidade', 'festa'];
  let proximaCena = floor(random(cenas.length));
  cenaAtual = cenas[proximaCena];
  // Garante que o personagem volte para a área da festa se estiver lá
  if (cenaAtual === 'festa') {
    personagem.x = areaFesta.x + areaFesta.largura / 2;
    personagem.y = areaFesta.y + areaFesta.altura / 2;
  }
}

// Classe Personagem
class Personagem {
  constructor() {
    this.x = width / 2;
    this.y = height * 0.75;
    this.tamanho = 30;
    this.velocidade = 4;
  }

  show() {
    fill(0, 0, 255); // Azul
    // Se tiver imagem, descomente e use:
    // if (imgPersonagem) {
    //   image(imgPersonagem, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
    // } else {
      ellipse(this.x, this.y, this.tamanho, this.tamanho); // Círculo simples
    // }
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o personagem à tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  coletou(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < (this.tamanho / 2 + item.tamanho / 2);
  }
}

// Classe Item Coletável
class Item {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.tipo = tipo; // 'flor' ou 'violao'
  }

  show() {
    if (this.tipo === 'flor') {
      fill(255, 0, 255); // Rosa
      // Se tiver imagem, descomente e use:
      // if (imgFlor) {
      //   image(imgFlor, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
      // } else {
        ellipse(this.x, this.y, this.tamanho, this.tamanho); // Flor simples
        fill(255, 255, 0);
        ellipse(this.x, this.y, this.tamanho / 2, this.tamanho / 2); // Centro
      // }
    } else { // violao (cidade)
      fill(160, 82, 45); // Marrom
      // Se tiver imagem, descomente e use:
      // if (imgViolao) {
      //   image(imgViolao, this.x - this.tamanho / 2, this.y - this.tamanho / 2, this.tamanho, this.tamanho);
      // } else {
        rect(this.x, this.y, this.tamanho, this.tamanho * 1.5); // Corpo
        rect(this.x + this.tamanho / 2 - 2, this.y - 10, 4, 15); // Braço
      // }
    }
  }
}

function criarItem(origem) {
  let x = random(width);
  let y = random(height * 0.2, height * 0.6); // Para não sobrepor o personagem ou o chão
  if (origem === 'campo') {
    itensCampo.push(new Item(x, y, 'flor'));
  } else { // cidade
    itensCidade.push(new Item(x, y, 'violao'));
  }
}

// Classe Área da Festa
class AreaFesta {
  constructor() {
    this.x = width * 0.75;
    this.y = height * 0.75;
    this.largura = 150;
    this.altura = 100;
  }

  show() {
    fill(255, 200, 0, 150); // Amarelo transparente
    rect(this.x, this.y, this.largura, this.altura);
    fill(0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text('ÁREA DA FESTA', this.x + this.largura / 2, this.y + this.altura / 2);
    textAlign(LEFT, BASELINE); // Volta ao padrão
  }
}